Commands

docker build -t celepar-k8s .

docker run -d --rm --name celepar-k8s -p 8080:8080 celepar-k8s

docker images

#Fazer o docker login gerando auth token, mais a url do repositorio

docker tag SOURCE_IMAGE[:TAG] TARGET_IMAGE[:TAG]


docker tag celepar-k8s:latest ocirepo


Fazer o docker pull e push

Fazer o acceso ao cluster

kubectl create namespace <<nomes-dos-alunos>>

kubectl -n nomes-dos-alunos create secret docker-registry my-docker-credentials \
  --docker-username=myusername \
  --docker-password=mypassword \
  --docker-email=myemail@example.com


  kubectl apply -f my-docker-credentials.yaml

