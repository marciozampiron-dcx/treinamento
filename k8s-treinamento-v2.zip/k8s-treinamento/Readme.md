Commands

docker build -t procergs-k8s .

docker run -d --rm --name procergs-k8s -p 8080:8080 procergs-k8s

docker images

#Fazer o docker login gerando auth token, mais a url do repositorio


docker login -u 'gr7r3azoxkhl/lab-treinamento/flavio-carmo' gru.ocir.io 

docker login  gru.ocir.io


docker tag SOURCE_IMAGE[:TAG] TARGET_IMAGE[:TAG]

docker tag procergs-fit:0.0.9  gru.ocir.io/gr7r3azoxkhl/lab-treinamento/procergs-fit:latest


docker tag procergs-k8s:latest ocirepo


Fazer o docker pull e push

Fazer o acceso ao cluster

kubectl create namespace <<nomes-dos-alunos>>


kubectl -n flavio-carmo run  busy --image=busybox -- /bin/sh -c "sleep 5000"

kubectl -n flavio-carmo run nginx --image=nginx

kubectl -n flavio-carmo expose po nginx --port 8080 --target-port 80

kubectl -n nomes-dos-alunos create secret docker-registry my-docker-credentials \
  --docker-username=myusername \
  --docker-password=mypassword 


  kubectl apply -f my-docker-credentials.yaml



#HELM

helm install my-release oci://registry-1.docker.io/bitnamicharts/wordpress

helm install wordpress oci://registry-1.docker.io/bitnamicharts/wordpress --create-namespace  -n  wordpress
